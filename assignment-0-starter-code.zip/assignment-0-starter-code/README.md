# Assignment0Starter
Starter Code for COMP 3501 - Assignment 0

## Instructions
Make all your edits in aZero.py, do not alter any other files 
this may impact the grader. 

Do not alter the test cases in any way, any attempt to do so will be treated as acamdeic dishonesty and will result in a zero on the assignment. 

If you hardcode the solution to a question, you will not recieve any credit for that answer. 

## Running the tests
To run the tests, run the following command in the terminal:
```pytest testCases/<testName>```

