#Student Name: <Your Name>
#Student ID: <Your ID>

import pandas as pd
import numpy as np
from scipy import stats

import A0_Utils as A0

## Question 1 - Basics

def add(a, b):
    types = [int, float, str, list]
    if not (type(a) in types and type(b) in types):
        return None

    # Check if both are numbers (int or float)
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return a + b
    # Check if one is a str and the other is int or float
    if (isinstance(a, str) and isinstance(b, (int, float))) or (isinstance(b, str) and isinstance(a, (int, float))):
        return str(a) + str(b)
    # Same type then add
    if type(a) == type(b):
        return a + b
    # For all other types concat
    return str(a) + str(b)
A0.raiseNotDefined()

def calcMyGrade(AssignmentScores, MidtermScores, PracticumScores, ICAScores, Weights):

    scores = [AssignmentScores, MidtermScores, PracticumScores, ICAScores]
    # Calculate the avg as a fraction
    avgs = [sum(s)/len(s)/100 if s else 0 for s in scores]
    total_weight = sum(Weights)
    norm_weights = [w/total_weight for w in Weights]
    return sum(a*w for a, w in zip(avgs, norm_weights)) * 100
A0.raiseNotDefined()


## Question 2 - Classes

class node:
    # See Question 2a
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.leftchild = None
        self.rightchild = None

    def getChildren(self):
        return [self.leftchild, self.rightchild]

    def getKey(self):
        return self.key

    def getValue(self):
        return self.value

    def assignLeftChild(self, child):
        self.leftchild = child

    def assignRightChild(self, child):
        self.rightchild = child

    def inOrderTraversal(self):
        result = []
        if self.leftchild:
            result += self.leftchild.inOrderTraversal()
        result.append(self.value)
        if self.rightchild:
            result += self.rightchild.inOrderTraversal()
        return result
A0.raiseNotDefined()

class queue:
    def __init__(self):
        self.items = []

    def push(self, value):
        self.items.append(value)

    def pop(self):
        if self.items:
            return self.items.pop(0)
        else:
            return None

    def checkSize(self):
        return len(self.items)
     
A0.raiseNotDefined()



def generateMatrix(numRows, numcolumns, minVal, maxVal):
    return np.random.randint(minVal, maxVal + 1, size=(numRows, numcolumns)).astype(float)
A0.raiseNotDefined()

def multiplyMat(m1, m2):
    try:
        return np.matmul(m1, m2)
    except ValueError:
        print("Incompatible Matrices")
        return None
A0.raiseNotDefined()

def statsTuple(a, b):
    try:
        sum_a = int(np.sum(a))
        mean_a = float(np.mean(a))
        min_a = int(np.min(a))
        max_a = int(np.max(a))
        sum_b = int(np.sum(b))
        mean_b = float(np.mean(b))
        min_b = int(np.min(b))
        max_b = int(np.max(b))
        pearson = round(float(stats.pearsonr(a, b)[0]), 2)
        spearman = round(float(stats.spearmanr(a, b)[0]), 2)
        return (sum_a, mean_a, min_a, max_a, sum_b, mean_b, min_b, max_b, pearson, spearman)
    except Exception:
        return None
A0.raiseNotDefined()

def pandas_func(fileName):
    try:
        df = pd.read_csv(fileName, sep='\t')
        ListOfMeans = []
        ListOfColumnNames = []
        for col in df.columns:
            if pd.api.types.is_numeric_dtype(df[col]):
                ListOfMeans.append(round(float(df[col].mean()), 2))
            else:
                ListOfColumnNames.append(col)
        return ListOfMeans, ListOfColumnNames
    except Exception:
        return None
A0.raiseNotDefined()